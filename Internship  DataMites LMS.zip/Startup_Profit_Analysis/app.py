import streamlit as st
import pandas as pd
import joblib
import mysql.connector
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error


# =========================================================
# 1. PAGE CONFIG
# =========================================================
st.set_page_config(
    page_title="Startup Profit Analytics",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)


# =========================================================
# 2. PREMIUM DARK DASHBOARD THEME
# =========================================================
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

:root {
    --bg: #070d1c;
    --panel: #0d1830;
    --panel2: #101f3b;
    --border: #1d3154;
    --muted: #8fa4c4;
    --text: #edf4ff;
    --cyan: #22d3ee;
    --blue: #3b82f6;
}
.stApp {
    background: radial-gradient(circle at 80% 0%, #10264a 0%, #080f20 42%, #070d1c 100%);
    color: var(--text);
    font-family: 'Inter', sans-serif;
}
.block-container {
    max-width: 1600px;
    padding-top: 1.4rem;
    padding-bottom: 2.5rem;
}
h1, h2, h3, h4, p, label { color: var(--text); }
h1 { font-weight: 800 !important; letter-spacing: -1px; }
h2, h3 { font-weight: 700 !important; }
[data-testid="stSidebar"] {
    background: #080f20;
    border-right: 1px solid #1a2b49;
}
[data-testid="stSidebar"] * { color: #dce8fa; }
[data-testid="stMetric"] {
    background: linear-gradient(145deg, #122443, #0d1930);
    border: 1px solid #20395f;
    border-radius: 15px;
    padding: 17px 18px;
    min-height: 112px;
    box-shadow: 0 8px 24px rgba(0,0,0,.18);
}
[data-testid="stMetricLabel"] {
    color: #91a8ca !important;
    font-size: 0.82rem !important;
}
[data-testid="stMetricValue"] {
    color: #eaf5ff !important;
    font-size: 1.55rem !important;
    font-weight: 800 !important;
}
[data-testid="stMetricDelta"] { font-size: .75rem; }
div[data-testid="stVerticalBlockBorderWrapper"] {
    background: rgba(13, 24, 48, .82);
    border: 1px solid #1d3154;
    border-radius: 16px;
}
.stButton > button, .stDownloadButton > button {
    background: linear-gradient(90deg, #2563eb, #0891b2);
    color: white;
    border: 0;
    border-radius: 10px;
    font-weight: 700;
    min-height: 2.5rem;
}
.stButton > button:hover, .stDownloadButton > button:hover {
    border: 1px solid #67e8f9;
    color: white;
}
div[data-testid="stDataFrame"] {
    border: 1px solid #20395f;
    border-radius: 12px;
}
hr { border-color: #203454; }
.caption, [data-testid="stCaptionContainer"] { color: #91a8ca; }
div[data-baseweb="select"] > div, div[data-baseweb="input"] > div {
    background: #101f3b;
    border-color: #29466e;
}
.stRadio label, .stMultiSelect label { color: #c9d8ed !important; }
.dashboard-hero {
    background: linear-gradient(115deg, #101d38 0%, #132b50 58%, #07506a 100%);
    border: 1px solid #245078;
    border-radius: 20px;
    padding: 25px 28px;
    margin-bottom: 20px;
    box-shadow: 0 12px 35px rgba(0,0,0,.2);
}
.eyebrow {
    color: #67e8f9;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.6px;
}
.hero-title {
    color: #f8fbff;
    font-size: 34px;
    font-weight: 800;
    margin: 10px 0 4px 0;
}
.hero-subtitle { color: #a9bdd9; font-size: 13px; }
.panel-title {
    font-size: 15px;
    font-weight: 700;
    color: #e8f2ff;
    margin: 0 0 10px 0;
}
.small-note { color: #8299ba; font-size: 11px; }
[data-testid="stTabs"] button {
    color: #a9bdd9;
    font-weight: 600;
}
[data-testid="stTabs"] button[aria-selected="true"] {
    color: #67e8f9;
}
footer { visibility: hidden; }
</style>
""", unsafe_allow_html=True)


# =========================================================
# 3. LOAD MODEL AND MYSQL DATA
# =========================================================
@st.cache_resource
def load_model():
    return joblib.load("startup_profit_model.pkl")


@st.cache_data(ttl=60)
def load_startup_data():
    config = dict(st.secrets["mysql"])
    connection = mysql.connector.connect(**config)
    try:
        query = """
            SELECT RD_Spend, Administration, Marketing_Spend, State, Profit
            FROM startup
        """
        return pd.read_sql(query, connection)
    finally:
        connection.close()


try:
    model = load_model()
    df = load_startup_data()
except Exception as e:
    st.error(f"Unable to load the model or database: {e}")
    st.info(
        "Check that startup_profit_model.pkl exists in the app folder "
        "and that .streamlit/secrets.toml contains the correct MySQL settings."
    )
    st.stop()

if df.empty:
    st.warning("No startup records were returned from the database.")
    st.stop()

required_columns = ["RD_Spend", "Administration", "Marketing_Spend", "State", "Profit"]
missing_columns = [col for col in required_columns if col not in df.columns]
if missing_columns:
    st.error(f"Missing database columns: {', '.join(missing_columns)}")
    st.stop()

for col in ["RD_Spend", "Administration", "Marketing_Spend", "Profit"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")
df = df.dropna(subset=required_columns).copy()
df["State"] = df["State"].astype(str)
df["Total_Investment"] = (
    df["RD_Spend"] + df["Administration"] + df["Marketing_Spend"]
)
# This is a profit-to-investment ratio, not an accounting profit margin.
df["Profit_Investment_Ratio"] = np.where(
    df["Total_Investment"] != 0,
    df["Profit"] / df["Total_Investment"] * 100,
    np.nan
)

if df.empty:
    st.warning("No valid startup records are available after data cleaning.")
    st.stop()


# =========================================================
# 4. SIDEBAR NAVIGATION AND FILTERS
# =========================================================
st.sidebar.markdown("## 🚀 Startup Analytics")
st.sidebar.caption("BUSINESS INTELLIGENCE PLATFORM")
st.sidebar.divider()

page = st.sidebar.radio(
    "WORKSPACE",
    [
        "Dashboard",
        "Advanced Analytics",
        "Startup Records",
        "Model Performance",
        "Profit Prediction"
    ],
    label_visibility="visible"
)

st.sidebar.divider()
st.sidebar.markdown("#### Database")
if st.sidebar.button("↻ Refresh Database", use_container_width=True):
    load_startup_data.clear()
    st.rerun()

st.sidebar.caption(f"Database records: {len(df)}")

available_states = sorted(df["State"].dropna().unique().tolist())
selected_states = st.sidebar.multiselect(
    "Filter by State",
    options=available_states,
    default=available_states
)

filtered_df = df[df["State"].isin(selected_states)].copy()
if filtered_df.empty:
    st.warning("Select at least one state from the sidebar filter.")
    st.stop()


# =========================================================
# 5. HEADER
# =========================================================
st.markdown("""
<div class="dashboard-hero">
    <div class="eyebrow">● BUSINESS INTELLIGENCE &nbsp; / &nbsp; LIVE ANALYTICS</div>
    <div class="hero-title">Startup Profit <span style="color:#22d3ee;">Analytics</span></div>
    <div class="hero-subtitle">
        Investment insights &nbsp; • &nbsp; Business performance &nbsp; • &nbsp; Machine learning predictions
    </div>
</div>
""", unsafe_allow_html=True)

st.caption("₹ is a display symbol only. The original dataset currency has not been verified.")


# =========================================================
# 6. CHART HELPERS (VEGA-LITE)
# =========================================================
def show_donut(data, category, value, height=250):
    chart_data = data[[category, value]].dropna()
    spec = {
        "data": {"values": chart_data.to_dict(orient="records")},
        "mark": {"type": "arc", "innerRadius": 62, "stroke": "#0b1730", "strokeWidth": 3},
        "encoding": {
            "theta": {"field": value, "type": "quantitative"},
            "color": {
                "field": category,
                "type": "nominal",
                "scale": {"scheme": "tableau20"},
                "legend": {"labelColor": "#c7d8ef", "titleColor": "#c7d8ef"}
            },
            "tooltip": [
                {"field": category, "type": "nominal", "title": "Category"},
                {"field": value, "type": "quantitative", "title": "Value", "format": ",.2f"}
            ]
        },
        "view": {"stroke": None},
        "config": {"background": "transparent"}
    }
    st.vega_lite_chart(spec, use_container_width=True, height=height)


def show_bar(data, category, value, height=260, color="#2389e8"):
    chart_data = data[[category, value]].dropna()
    spec = {
        "data": {"values": chart_data.to_dict(orient="records")},
        "mark": {"type": "bar", "cornerRadiusTopLeft": 5, "cornerRadiusTopRight": 5, "color": color},
        "encoding": {
            "x": {
                "field": category, "type": "nominal",
                "axis": {"labelColor": "#9db1ce", "titleColor": "#9db1ce", "labelAngle": 0, "grid": False}
            },
            "y": {
                "field": value, "type": "quantitative",
                "axis": {"labelColor": "#9db1ce", "titleColor": "#9db1ce", "gridColor": "#203454"}
            },
            "tooltip": [
                {"field": category, "type": "nominal"},
                {"field": value, "type": "quantitative", "format": ",.2f"}
            ]
        },
        "view": {"stroke": None},
        "config": {"background": "transparent"}
    }
    st.vega_lite_chart(spec, use_container_width=True, height=height)


def show_line(data, x_field, y_field, height=250):
    chart_data = data[[x_field, y_field]].dropna().to_dict(orient="records")
    spec = {
        "data": {"values": chart_data},
        "mark": {"type": "line", "point": {"filled": True, "size": 65}, "strokeWidth": 3, "color": "#22c7e8"},
        "encoding": {
            "x": {
                "field": x_field, "type": "nominal",
                "axis": {"labelColor": "#9db1ce", "titleColor": "#9db1ce", "labelAngle": 0}
            },
            "y": {
                "field": y_field, "type": "quantitative",
                "axis": {"labelColor": "#9db1ce", "titleColor": "#9db1ce", "gridColor": "#203454"}
            },
            "tooltip": [
                {"field": x_field, "type": "nominal"},
                {"field": y_field, "type": "quantitative", "format": ",.2f"}
            ]
        },
        "view": {"stroke": None},
        "config": {"background": "transparent"}
    }
    st.vega_lite_chart(spec, use_container_width=True, height=height)


# =========================================================
# 7. DASHBOARD PAGE
# =========================================================
if page == "Dashboard":
    st.markdown("### Overview")
    st.caption("A snapshot of startup investment and profit performance.")

    total_startups = len(filtered_df)
    avg_profit = filtered_df["Profit"].mean()
    total_investment = filtered_df["Total_Investment"].sum()
    avg_ratio = filtered_df["Profit_Investment_Ratio"].mean()

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("TOTAL STARTUPS", f"{total_startups:,}")
    k2.metric("AVERAGE PROFIT", f"{avg_profit:,.2f}")
    k3.metric("TOTAL INVESTMENT", f"{total_investment:,.2f}")
    k4.metric("PROFIT / INVESTMENT", f"{avg_ratio:.2f}%" if pd.notna(avg_ratio) else "N/A")

    st.write("")
    left, right = st.columns([1, 1.45], gap="large")

    with left:
        with st.container(border=True):
            st.markdown('<div class="panel-title">Startup distribution by state</div>', unsafe_allow_html=True)
            state_counts = (
                filtered_df.groupby("State").size()
                .reset_index(name="Startup_Count")
            )
            show_donut(state_counts, "State", "Startup_Count", 245)

    with right:
        with st.container(border=True):
            st.markdown('<div class="panel-title">Average profit by state</div>', unsafe_allow_html=True)
            state_profit = (
                filtered_df.groupby("State", as_index=False)["Profit"]
                .mean().sort_values("Profit", ascending=False)
            )
            show_bar(state_profit, "State", "Profit", 245, "#218ce8")

    st.write("")
    left, right = st.columns([1.35, 1], gap="large")

    with left:
        with st.container(border=True):
            st.markdown('<div class="panel-title">Investment components</div>', unsafe_allow_html=True)
            components = pd.DataFrame({
                "Investment": ["R&D", "Administration", "Marketing"],
                "Amount": [
                    filtered_df["RD_Spend"].sum(),
                    filtered_df["Administration"].sum(),
                    filtered_df["Marketing_Spend"].sum()
                ]
            })
            show_bar(components, "Investment", "Amount", 250, "#168ed5")

    with right:
        with st.container(border=True):
            st.markdown('<div class="panel-title">Profit distribution</div>', unsafe_allow_html=True)
            profit_bins = pd.cut(filtered_df["Profit"], bins=min(8, max(2, filtered_df["Profit"].nunique())))
            distribution = (
                profit_bins.value_counts().sort_index()
                .rename_axis("Profit_Range").reset_index(name="Startup_Count")
            )
            distribution["Profit_Range"] = distribution["Profit_Range"].astype(str)
            show_bar(distribution, "Profit_Range", "Startup_Count", 250, "#16b8c8")

    st.write("")
    with st.container(border=True):
        st.markdown('<div class="panel-title">Investment vs profit relationship</div>', unsafe_allow_html=True)
        scatter = filtered_df[["Total_Investment", "Profit", "State"]].copy()
        scatter_spec = {
            "data": {"values": scatter.to_dict(orient="records")},
            "mark": {"type": "circle", "filled": True, "opacity": 0.78, "size": 100},
            "encoding": {
                "x": {
                    "field": "Total_Investment", "type": "quantitative",
                    "title": "Total Investment",
                    "axis": {"labelColor": "#9db1ce", "titleColor": "#9db1ce", "gridColor": "#203454"}
                },
                "y": {
                    "field": "Profit", "type": "quantitative",
                    "title": "Profit",
                    "axis": {"labelColor": "#9db1ce", "titleColor": "#9db1ce", "gridColor": "#203454"}
                },
                "color": {
                    "field": "State", "type": "nominal",
                    "scale": {"scheme": "tableau20"},
                    "legend": {"labelColor": "#c7d8ef", "titleColor": "#c7d8ef"}
                },
                "tooltip": [
                    {"field": "State", "type": "nominal"},
                    {"field": "Total_Investment", "type": "quantitative", "format": ",.2f"},
                    {"field": "Profit", "type": "quantitative", "format": ",.2f"}
                ]
            },
            "view": {"stroke": None},
            "config": {"background": "transparent"}
        }
        st.vega_lite_chart(scatter_spec, use_container_width=True, height=310)

    st.write("")
    with st.container(border=True):
        st.markdown('<div class="panel-title">Recent startup records</div>', unsafe_allow_html=True)
        st.dataframe(
            filtered_df[required_columns + ["Total_Investment"]].head(10),
            use_container_width=True,
            hide_index=True
        )


# =========================================================
# 8. ADVANCED ANALYTICS
# =========================================================
elif page == "Advanced Analytics":
    st.markdown("### Advanced Business Analytics")
    st.caption("Explore investment patterns, state performance and relationships in the available records.")

    a1, a2, a3, a4 = st.columns(4)
    a1.metric("Maximum Profit", f"{filtered_df['Profit'].max():,.2f}")
    a2.metric("Minimum Profit", f"{filtered_df['Profit'].min():,.2f}")
    a3.metric("Average Investment", f"{filtered_df['Total_Investment'].mean():,.2f}")
    a4.metric("Average Profit / Investment", f"{filtered_df['Profit_Investment_Ratio'].mean():.2f}%")

    st.divider()
    state_analysis = (
        filtered_df.groupby("State")
        .agg(
            Average_Profit=("Profit", "mean"),
            Total_Profit=("Profit", "sum"),
            Startup_Count=("Profit", "count")
        )
        .sort_values("Average_Profit", ascending=False)
        .reset_index()
    )

    lcol, rcol = st.columns(2)
    with lcol:
        st.markdown("#### Average profit by state")
        show_bar(state_analysis, "State", "Average_Profit", 270)
    with rcol:
        st.markdown("#### Total profit by state")
        show_bar(state_analysis, "State", "Total_Profit", 270, "#14b8a6")
    st.dataframe(state_analysis, use_container_width=True, hide_index=True)

    st.divider()
    st.markdown("#### Investment vs profit relationship")
    scatter = filtered_df[["Total_Investment", "Profit", "State"]].copy()
    spec = {
        "data": {"values": scatter.to_dict(orient="records")},
        "mark": {"type": "circle", "filled": True, "opacity": 0.75, "size": 110},
        "encoding": {
            "x": {"field": "Total_Investment", "type": "quantitative", "title": "Total Investment"},
            "y": {"field": "Profit", "type": "quantitative", "title": "Profit"},
            "color": {"field": "State", "type": "nominal", "scale": {"scheme": "tableau20"}},
            "tooltip": [{"field": "State"}, {"field": "Total_Investment", "format": ",.2f"}, {"field": "Profit", "format": ",.2f"}]
        },
        "config": {"background": "transparent", "axis": {"labelColor": "#9db1ce", "titleColor": "#9db1ce", "gridColor": "#203454"}}
    }
    st.vega_lite_chart(spec, use_container_width=True, height=330)

    st.divider()
    st.markdown("#### Investment component totals")
    component_data = pd.DataFrame({
        "Component": ["R&D Spend", "Administration", "Marketing Spend"],
        "Total": [
            filtered_df["RD_Spend"].sum(),
            filtered_df["Administration"].sum(),
            filtered_df["Marketing_Spend"].sum()
        ]
    })
    show_bar(component_data, "Component", "Total", 260, "#168ed5")
    st.dataframe(component_data, use_container_width=True, hide_index=True)

    st.divider()
    st.markdown("#### Correlation analysis")
    correlation = filtered_df[
        ["RD_Spend", "Administration", "Marketing_Spend", "Total_Investment", "Profit"]
    ].corr()
    st.dataframe(correlation.round(3), use_container_width=True)

    st.caption("Correlation measures linear association. It does not establish causation.")

    csv_data = filtered_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Download analytics data",
        data=csv_data,
        file_name="startup_advanced_analytics.csv",
        mime="text/csv"
    )


# =========================================================
# 9. STARTUP RECORDS
# =========================================================
elif page == "Startup Records":
    st.markdown("### Startup Records")
    st.caption(f"Showing {len(filtered_df)} records based on the selected state filter.")
    st.dataframe(filtered_df, use_container_width=True, hide_index=True)
    csv_data = filtered_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Download startup records",
        data=csv_data,
        file_name="startup_records.csv",
        mime="text/csv"
    )


# =========================================================
# 10. MODEL PERFORMANCE
# =========================================================
elif page == "Model Performance":
    st.markdown("### Machine Learning Model Performance")
    st.caption("Evaluation uses a reproducible 80/20 split of the available dataset.")

    X = df[["RD_Spend", "Administration", "Marketing_Spend", "State"]]
    y = df["Profit"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    try:
        y_pred = model.predict(X_test)
        r2 = r2_score(y_test, y_pred)
        mae = mean_absolute_error(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))

        m1, m2, m3 = st.columns(3)
        m1.metric("R² SCORE", f"{r2:.4f}")
        m2.metric("MAE", f"{mae:,.2f}")
        m3.metric("RMSE", f"{rmse:,.2f}")

        st.caption("R² measures explained variation. MAE and RMSE measure prediction error.")
        comparison = pd.DataFrame({
            "Actual Profit": y_test.to_numpy(),
            "Predicted Profit": y_pred
        }).reset_index(drop=True)

        st.markdown("#### Actual vs predicted profit")
        plot_data = comparison.reset_index().rename(columns={"index": "Test Record"})
        line_spec = {
            "data": {"values": plot_data.to_dict(orient="records")},
            "mark": {"type": "line", "point": True},
            "encoding": {
                "x": {"field": "Test Record", "type": "ordinal", "title": "Test record"},
                "y": {"field": "Profit", "type": "quantitative"},
                "color": {"field": "Series", "type": "nominal"}
            },
            "transform": [
                {"fold": ["Actual Profit", "Predicted Profit"], "as": ["Series", "Profit"]}
            ],
            "config": {"background": "transparent", "axis": {"labelColor": "#9db1ce", "titleColor": "#9db1ce", "gridColor": "#203454"}}
        }
        st.vega_lite_chart(line_spec, use_container_width=True, height=320)
        st.dataframe(comparison, use_container_width=True, hide_index=True)

        result_csv = comparison.to_csv(index=False).encode("utf-8")
        st.download_button(
            "⬇️ Download model results",
            data=result_csv,
            file_name="model_performance.csv",
            mime="text/csv"
        )
    except Exception as e:
        st.error(f"Model evaluation error: {e}")


# =========================================================
# 11. PROFIT PREDICTION
# =========================================================
elif page == "Profit Prediction":
    st.markdown("### Startup Profit Prediction")
    st.caption("Enter investment values and select a state to estimate startup profit.")

    with st.container(border=True):
        p1, p2, p3 = st.columns(3)
        with p1:
            rd_spend = st.number_input("R&D Spend", min_value=0.0, value=160000.0, step=1000.0)
        with p2:
            administration = st.number_input("Administration", min_value=0.0, value=120000.0, step=1000.0)
        with p3:
            marketing_spend = st.number_input("Marketing Spend", min_value=0.0, value=200000.0, step=1000.0)

        state_options = sorted(df["State"].unique().tolist())
        state = st.selectbox("Select startup state", state_options)

        predict_clicked = st.button("🚀 Predict Startup Profit", type="primary", use_container_width=True)

    if predict_clicked:
        input_data = pd.DataFrame({
            "RD_Spend": [rd_spend],
            "Administration": [administration],
            "Marketing_Spend": [marketing_spend],
            "State": [state]
        })

        try:
            prediction = model.predict(input_data)[0]
            total_investment_input = rd_spend + administration + marketing_spend
            ratio = (prediction / total_investment_input * 100) if total_investment_input else np.nan

            st.write("")
            st.success("Prediction generated successfully.")
            r1, r2, r3 = st.columns(3)
            r1.metric("PREDICTED PROFIT", f"{prediction:,.2f}")
            r2.metric("TOTAL INVESTMENT", f"{total_investment_input:,.2f}")
            r3.metric("PROFIT / INVESTMENT", f"{ratio:.2f}%" if pd.notna(ratio) else "N/A")

            st.caption("This is a model estimate, not a guaranteed business outcome.")
        except Exception as e:
            st.error(f"Prediction error: {e}")


# =========================================================
# 12. FOOTER
# =========================================================
st.divider()
st.caption("Startup Profit Analytics  •  MySQL Database  •  Advanced Analytics  •  Machine Learning")
